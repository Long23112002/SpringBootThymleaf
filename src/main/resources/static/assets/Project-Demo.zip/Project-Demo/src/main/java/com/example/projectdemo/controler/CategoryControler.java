package com.example.projectdemo.controler;

import com.example.projectdemo.model.Products;
import com.example.projectdemo.service.ProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;

import java.util.List;

@Controller

public class CategoryControler {

    private ProductService productService;
    @Autowired
    public void setProductService(ProductService productService) {
        this.productService = productService;
    }

    @RequestMapping("admin/category")
    public String index(){
        return ("admin/category/index");
    }
    @RequestMapping("admin/add-category")
    public String add(){
        return "admin/category/add";
    }


    @GetMapping("/loadProducts")
    public String addProducts(Model model ){
        List<Products> listProducts = productService.getAllProducts();
        model.addAttribute("listProducts",listProducts);
        return ("admin/fragments/table-admin");
    }


}
